1. [[#Syncthing|Syncthing]]
2. [[#Nextcloud|Nextcloud]]
3. [[#Obsidian|Obsidian]]

> [!NOTE] ## Syncthing
> [Syncthing](https://syncthing.net) is a desktop syncing client that is relatively easy to use but doesn't support user designation, so every device needs to be added individually so setup isn't simple but a tech savvy admin could probably get the hang of it within a few minutes. An advantage of [Syncthing](https://syncthing.net) is that it uses next to no compute resources.
> 
> [Syncthing Docs](https://docs.syncthing.net/)

>[!NOTE] ## Nextcloud
>On the other hand, [Nextcloud](https://nextcloud.com) is like a self-hosted Google Drive. It supports users so the device adding issue doesn't occur. But a downside of [Nextcloud](https://nextcloud.com) is unlike [Syncthing](https://syncthing.net) it's hosted which means it requires a server. But an advantage that comes with that is it doesn't store data on every synced device by default and allows access through a web portal. [Nextcloud](https://nextcloud.com) also supports apps like Face Recognition for Photos stored in [Nextcloud](https://nextcloud.com) (like Google Photos).
 >
 >[Nextcloud Docs](https://docs.nextcloud.com)

> [!NOTE] ## Obsidian
> [Obsidian](http://obsidian.md) isn't a document syncing solution but it's a [Markdown](https://daringfireball.net/projects/markdown/)-based note taking app that's super customizable and my pick for favourite text editor. 
>
[Obsidian Docs](https://help.obsidian.md)

