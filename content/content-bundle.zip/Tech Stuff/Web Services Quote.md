
<center><head>CG  Web Services Quote</head></center>
|          | Subscription Payment Interval | Payment / period | yearly total |
| -------- | ------- | ----------------------------- | ---------------- |
| Domain | / year  | $19.99 US | $31.07 |
| Cloudron | / month | $15 US | $279.74 |
| Server Hosting (2 CPU Cores, 80 GB Storage, 4 GB RAM) | / month | $20.00	US | $373.03 | 
| Service Fee | / month | $2 CAD | $24 |

|          |              |
| -------- | ------------ |
| Subtotal | $707.84      |
| Tax      | $48          |
| Total    | $755.97/Year |
