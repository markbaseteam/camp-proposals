## What & Why
I think that if camp is affected by covid restrictions again it would be worth considering doing more streaming. It might be worth streaming (all-camp) services, song sesh and, the play. First it would be a good idea to survey camp parents to ask their feelings about it. Also, this could be a good way to keep alumni engaged with camp. 

Secondarily, this would be a great way to get more out of the new camper orientation or camper recruitment events. You'd be able to run it from one location and stream it to multiple locations which could allow admin to have to travel less. 

## Technical Side

There are a couple of options of a solution to use for self-hosted video streaming:

|                  | Service Website         | Demo               |
| ---------------- | ----------------------- | ------------------ |
| Ant Media Server | https://antmedia.io/    |                    |
| Owncast          | https://owncast.online/ | https://oc.samgreenwood.ca |
| PeerTube | https://joinpeertube.org/ | https://tube.samgreenwood.ca/ |

### Hardware

#### My Suggestion
 - [Blackmagic Design (BMD) ATEM Mini](https://www.blackmagicdesign.com/products/atemmini) (2)
 - [Blackmagic Pocket Cinema Camera 4K](https://www.blackmagicdesign.com/products/blackmagicpocketcinemacamera) (4)
 - [Elgato Stream Deck XL](https://www.elgato.com/en/stream-deck-xl) (2)
 - [Blackmagic Design DeckLink](https://www.blackmagicdesign.com/products/decklink)
 - [Hollyland Mars 300 Pro HDMI Wireless Video System](https://hollyland-tech.com/detail-mars300pro)

I'm pretty sure that [AVShop.ca](https://AVShop.ca) offers a not-for-profit discount. They offer leasing and financing on all orders. 

%%
```button
name Link to Flowchart
type link
action https://h2rgear.com/plan/f5maiNIkPpbbC10JqM21
```
^button-Flowchart-button
%%
#### Software
[Isadora](https://troikatronix.com/)
[Universe Control](https://universe-control.com/)
[H2R Graphics](https://h2r.graphics)
[Bitfocus Companion](https://bitfocus.io/companion)