- [[#How to Effectivly Lead/Leadership @ Camp|How to Effectivly Lead/Leadership @ Camp]]
- [[#Responsabilities|Responsabilities]]
- [[#From Camper-Staff Dynamics To Staff-Superviser Dynamics: How to Manage with Your Staff|From Camper-Staff Dynamics To Staff-Superviser Dynamics: How to Manage with Your Staff]]


## How to Effectivly Lead/Leadership @ Camp
- leadership activity
- what qualities make a good leader (and how they can be applied @ camp)
- 

## Responsabilities
- 

## From Camper-Staff Dynamics To Staff-Superviser Dynamics: How to Manage with Your Staff
- differences and similarities between being a general staff member and Hanhallah
- 