## Table of Contents
- [[#Week 1|Week 1]]
- [[#Week 2|Week 2]]
- [[#Week 3|Week 3]]
- [[#Week 4|Week 4]]
- [[#Week 5|Week 5]]
- [[#Week 6|Week 6]]

## Week 1
| Weekly Events | Sessions                                                                                        |
| ------------- | ----------------------------------------------------------------------------------------------- |
|               | Intro                                                                                           |
|               | [[Sessions#How to Effectivly Lead/Leadership @ Camp\|How to Effectivly Lead/Leadership @ Camp]] |

%% ## Week 2
| Weekly Events | Sessions |
| ------------- | -------- |
|               |          |
|               |          |
%%
## Week 3
| Weekly Events |  Sessions |
| ------------- | -------- |
| Midsummer Reflection |  Intro to Shaddow Component |
|               | [Responsabilities](Sessions.md#Responsabilities)         |
       

## Week 4
| Weekly Events | Sessions |
| ------------- | -------- |
| Midsummer Reflection | [[Sessions#From Camper-Staff Dynamics To Staff-Superviser Dynamics: How to Manage with Your Staff\|Dynamics]] |
%%
## Week 5
| Weekly Events | Sessions |
| ------------- | -------- |
|               |          |
|               |          |

## Week 6
| Weekly Events | Sessions |
| ------------- | -------- |
|               |          |
|               |          |



