```toc
title: Table of Contents
```

I've been thinking about this one of a while. It first came to me around now last year but I started thinking about it again in the spring when I found out about  (and started listening to) *Campfires & Color Wars* a ***successful*** podcast about summer camp. 

I think starting a podcast would be a good way to keep alumni engaged and also be a tool to recruit campers.

## Format
- Have 1 or 2 alum members (or even current campers or staff) on to discuss their memories of to discuss their memories of to discuss their mem
## Setup
- 3x AKG Lyra USB condencor mic
- 1x Alesis MultiMix6 Mixing board
- 2x Mic stand
- 1x Mzc Mini
- 1x NAS
- 
## Other
