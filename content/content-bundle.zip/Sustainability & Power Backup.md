```toc
```
## Sustainability
- [Anorobic Digestion systam](https://homebiogas.com)

## Backup
- Solar
- [Source Hydropanels](https://www.source.co/)

These are really cool, you can see a video about them from a YT channel I like and trust:
<iframe width="560" height="315" src="https://www.youtube.com/embed/VQRAtwz3Igs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
- 