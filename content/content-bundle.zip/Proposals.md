```ccard
items: [
  {
    title: 'Hanhallah Mentoring Program',
    brief: 'Contains 0 folders, 7 notes.',
    foot: 'Hanhallah Mentoring Program',
    head: 'Folder'
  },
  {
    title: 'Tech Stuff',
    brief: 'Contains 0 folders, 4 notes.',
    foot: 'Tech Stuff',
    head: 'Folder'
  },
  {
    title: 'Camp Podcast',
    link: 'Proposals/Camp Podcast.md',
    brief: '/dyn',
    foot: '9/7/2022, 5:22:49 PM',
    head: 'Note'
  },
  {
    title: 'Head of Leadership Programming Position Proposal',
    link: 'Proposals/Head of Leadership Programming Position Proposal.md',
    brief: '`toc',
    foot: '8/27/2022, 9:50:10 PM',
    head: 'Note'
  },
  {
    title: 'Sustainability & Power Backup',
    link: 'Proposals/Sustainability & Power Backup.md',
    brief: '`toc',
    foot: '8/28/2022, 11:34:17 AM',
    head: 'Note'
  },
  {
    title: 'Table of Contents',
    link: 'Proposals/Table of Contents.md',
    brief: '%% Error: Cannot create a waypoint in a note that''s not the fold...',
    foot: '10/26/2022, 7:10:00 PM',
    head: 'Note'
  }
]
```
