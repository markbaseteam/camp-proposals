# Head of Leadership Programming

```toc
```
## What Staff in This Position Would Run
- [[Hanhallah Mentoring Program]]
- Leadership programming with Barak campers
- Other staff leadership programming

## Other Respnsabilities
- Work with Cornerstone Fellows (maybe hold liason position)
- Work with CIT Director on CIT Program
- for first few years (until other programs are developed) split role as assistant head of whatever department/unit the staff member had previously worked in.